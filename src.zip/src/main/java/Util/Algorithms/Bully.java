package Util.Algorithms;

import Util.Interfaces.BullyInterface;

public class Bully implements BullyInterface {

    @Override
    public void announceWinner() {
        // TODO Auto-generated method stub
    }

    @Override
    public void startElection() {
        // TODO Auto-generated method stub
    }

    @Override
    public void alive() {
        // TODO Auto-generated method stub
    }

}