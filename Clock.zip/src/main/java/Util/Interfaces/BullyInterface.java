package Util.Interfaces;

public interface BullyInterface {

    public void announceWinner();

    public void startElection();

    public void alive();
}